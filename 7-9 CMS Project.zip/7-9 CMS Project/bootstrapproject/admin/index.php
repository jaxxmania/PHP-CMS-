<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>My Website-First Project-Admin</title>
<link rel="stylesheet" type="text/css" href="../css/style.css"/>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="../fontawesome/css/all.css"/>
<link rel="stylesheet" type="text/css" href="../fontawesome/css/all.min.css"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
</head>


<body>
 <h2 class="page-header text-center text-info">Admin Dashboard</h2>
	 <div class="container-fluid">
	 		<div class="col-md-3">
	 			<div class="panel panel-group">
	 				 <div class="panel panel-default">
	 				 		<h2 class="bg-primary">Home</h2>
	 				 	  <ul class="nav nav-stacked">
	 				 	  		<ul class="list-group">
				 	  			 <li class="list-group-item"><a href="index.php?create_home">Create</a>	</li>
	 				 	  			 <li class="list-group-item">
	 				 	  			 	<a href="index.php?display_home">View</a>
	 				 	  			</li>

	 				 	  		</ul>
	 				 	  </ul>
 				 </div>
	 			</div>
	 		</div>
	 		<div class="col-md-9">
 			  <h2 class="page-header text-center text-info">Admin Panel CMS </h2>
	 			  <?php
	 			  	  if(isset($_GET['create_home']))
	 			  	  {
	 			  	  	include('create_home.php');
	 			  	  }
	 			  	  if(isset($_GET['display_home']))
	 			  	  {
	 			  	  	include('display_home.php');
	 			  	  }
 			  ?>
 		</div>
	 </div>
</body>
</html>
