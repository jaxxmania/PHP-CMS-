<form name="home_section" method="POST">

	   <h3>Insert Post For Home Section</h3>

	   <div class="form-group">

	   	   <label for="PostTitle">Post Title</label>

	   	   <input type="text" name="post_title" class="form-control" placeholder="Post Title For Home" required> 

	   </div>

	   <div class="form-group">

	   		<label for="PostDescription">Post Description</label>

	   		<textarea name="post_description" class="form-control"></textarea>


	   </div>
	   <div class="form-group">

	   	   <label for="PostIcon">Post Icon</label>

	   	   <input type="text" name="post_icon" class="form-control" placeholder="Post Icon For Home" required> 

	   </div>
	   

	  		<button type="submit" class="btn btn-info" name="btn_submit">Create Home</button>

	</form>
	<?php
		include('../include/connect.php');
  	 		if(isset($_POST['btn_submit']))
  	 		{

  	 			$title=$_POST['post_title'];
  	 			$desc=$_POST['post_description'];
  	 			$icon=$_POST['post_icon'];
  	 			$sql="insert into home_tbl(title,description,icon)values('$title','$desc','$icon')";
  	 			$qry=mysqli_query($con,$sql) or die(mysqli_error());
  	 			if($qry)
  	 			{
  	 				echo "<script>alert('Form Submitted')</script>";
  	 			}
  	 		}
  	 		else
  	 		{
  	 			echo "<script>alert('Something Wrong Happened')</script>";
  	 		}

	?>