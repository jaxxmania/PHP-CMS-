<?php

	$server="localhost";
	$user="root";
	$pass="";
	$dbname="bootstrap_project";
	$con=mysqli_connect($server,$user,$pass) or die(mysqli_error());
	mysqli_select_db($con,$dbname);
?>
